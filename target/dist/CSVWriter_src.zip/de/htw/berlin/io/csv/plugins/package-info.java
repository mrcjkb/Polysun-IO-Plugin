/**
 * 
 */
/**
 * PluginController library for sending data from Polysun to a CSV file
 * @author Marc Jakobi</p>HTW Berlin</p>July 2017
 * @see <a href="https://www.http://www.velasolaris.com/english/home.html">Polysun</a>
 */
package de.htw.berlin.io.csv.plugins;